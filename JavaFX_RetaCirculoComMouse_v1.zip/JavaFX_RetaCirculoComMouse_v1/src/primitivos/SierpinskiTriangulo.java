package primitivos;

import javafx.scene.canvas.GraphicsContext;

public class SierpinskiTriangulo
{
    public static void makeSierpinski(int base, Ponto p0, int iteracoes, GraphicsContext gc)
    {
        if(iteracoes > 0)
        {
            TrianguloEquilater t = new TrianguloEquilater(p0, base);
            t.drawTriangulo(gc);

            makeSierpinski(base / 2, p0, iteracoes - 1, gc);
            makeSierpinski(base / 2, new Ponto((t.p0.getx() + t.p1.getx())/2, (t.p0.gety() + t.p1.gety())/2),iteracoes - 1, gc );
            makeSierpinski(base / 2, new Ponto((t.p0.getx() + t.p2.getx())/2, (t.p0.gety() + t.p2.gety())/2),iteracoes - 1, gc );
        }
        else
            return;
    }
}
