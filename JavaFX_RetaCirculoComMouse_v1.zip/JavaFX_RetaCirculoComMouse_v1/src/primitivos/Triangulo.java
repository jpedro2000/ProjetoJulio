package primitivos;

import javafx.scene.canvas.GraphicsContext;

public class Triangulo
{
    Ponto p0, p1, p2;

    Triangulo(int x0, int y0, int x1, int y1, int x2, int y2)
    {
        this(new Ponto(x0, y0), new Ponto(x1, y1), new Ponto(x2,y2));
    }

    Triangulo(Ponto p0, Ponto p1, Ponto p2)
    {
        this.p0 = p0;
        this.p1 = p1;
        this.p2 = p2;
    }

    public void drawTriangulo(GraphicsContext g)
    {
        RetaGr reta0 = new RetaGr((int)p0.getx(), (int)p0.gety(), (int)p1.getx(),(int)p1.gety(), 1);
        RetaGr reta1 = new RetaGr((int)p1.getx(), (int)p1.gety(), (int)p2.getx(),(int)p2.gety(), 1);
        RetaGr reta2 = new RetaGr((int)p2.getx(), (int)p2.gety(), (int)p0.getx(),(int)p0.gety(), 1);
        reta0.desenhar(g,AlgoritmosRetas.STROKELINE);
        reta1.desenhar(g,AlgoritmosRetas.STROKELINE);
        reta2.desenhar(g,AlgoritmosRetas.STROKELINE);
    }


	public static void desenhar(GraphicsContext gc, int x1, int x2, int y1, int y2, AlgoritmosRetas alg) {
		// TODO Auto-generated method stub
		desenhar(gc,(int)x1, (int)x2, (int)y1, (int)y2,alg);
	}
}
