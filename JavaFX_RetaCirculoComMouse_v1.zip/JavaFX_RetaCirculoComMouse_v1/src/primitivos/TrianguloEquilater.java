package primitivos;

public class TrianguloEquilater extends Triangulo
{
    TrianguloEquilater(int base, int x0, int y0)
    {
        super(x0, y0, x0 + base, y0, x0 + base /2, (int)(y0 + (Math.sqrt(3) * base / 2)));
    }
    
    TrianguloEquilater(Ponto p0, int base)
    {
    		super((int)p0.getx(), (int)p0.gety(),
    			  (int)p0.getx() + base, (int)p0.gety(),
    			  (int)p0.getx() + base /2, (int)(p0.gety() + (Math.sqrt(3) * base / 2)));
    }
    
    public Ponto getP0()
    {
        return p0;
    }

    public Ponto getP1()
    {
        return p1;
    }

    public Ponto getP2()
    {
        return p2;
    }
}
