package primitivos;

public class Triangulo {
	

	public double calcularAltura(double base){
		return (base * Math.sqrt(3))/2;
	}
	
	public double calcularMeiaBase(double base){
		return base/2;
	}
}
